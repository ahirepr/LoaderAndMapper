package com.logilite.training.csvtodatabase;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public class PropertyReader {
	 public static void main(String args[]) throws IOException {
		
		 Properties prop = new Properties();
			try {
				// load a properties file for reading
				prop.load(new FileInputStream("src/resource/customer.properties"));
				// get the properties and print
			//	prop.list(System.out);
				//Reading each property value
				System.out.println(prop.getProperty("customerFirstName"));
				System.out.println(prop.getProperty("customerLastName"));
				System.out.println(prop.getProperty("customerAge"));
			//	System.out.println(prop.getProperty("TOPIC"));
			} catch (IOException ex) {
				ex.printStackTrace();
			}}
			/*
			 * Properties prop = readPropertiesFile(
			 * "/home/pankaj/extdrive/InitialAssignment/General/LoaderAndMapper/src/customer.properties"
			 * ); System.out.println("user: "+ prop.getProperty("customer_id"));
			 * System.out.println("password: "+ prop.getProperty("customer_fname"));
			 */
	   }
		/*
		 * public static Properties readPropertiesFile(String fileName) throws
		 * IOException { FileInputStream fis = null; Properties prop = null; try { fis =
		 * new FileInputStream(fileName); prop = new Properties(); prop.load(fis); }
		 * catch(FileNotFoundException fnfe) { fnfe.printStackTrace(); }
		 * catch(IOException ioe) { ioe.printStackTrace(); } finally { fis.close(); }
		 * return prop; }
		 */

