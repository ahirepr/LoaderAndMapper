package com.logilite.training.csvtodatabase;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.Scanner;

public class ReaderCsv {
	private static String url = "";
    private static String user = "";
    private static String password = "";
	
	public static void main(String[] args) throws IOException {
		 char c='\'';
		 Statement st=null;
		 Connection con=null;
		 ResultSet rs=null;
		 ReaderCsv readerCsv=new ReaderCsv();
		 readerCsv.setDatabaseProperties();
		 try {
			Class.forName("org.postgresql.Driver");
			  con=DriverManager.getConnection(url,user,password);
	         st=con.createStatement();
		   } catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
         System.out.println("hi.");
        
		String headers;
	    String line;
		Scanner sc=new Scanner(System.in);
		
		
		readerCsv.readPropertiesFile();
		System.out.println("enter the filename");
		String fileName=sc.next();
		String file = "src/resource/"+fileName+".csv";
		//String file = "/home/pankaj/extdrive/InitialAssignment/General/LoaderAndMapper/src/" +fileName+".csv";
	      
	       System.out.println(file);
	        try (BufferedReader br =
	                     new BufferedReader(new FileReader(file))) {
	            headers = br.readLine();
	           
	            while((line = br.readLine()) != null){
	                String[] record = line.split(",");
	                System.out.println(record[0]+" "+c+record[1]+c+" "+c+record[2]+c+" "+record[3]);
	              //  String query2="insert into customer("+prop.getProperty("customerFirstName")+prop.getProperty("customerFirstName")+prop.getProperty("customerFirstName"))
	                String query1="insert into "+fileName+" values("+record[0]+","+c+record[1]+c+","+c+record[2]+c+","+record[3]+");";
	                String query="insert into "+fileName+" values(nextval(\'customer_id_sequence\'),"+c+record[1]+c+","+c+record[2]+c+","+record[3]+");";
	                //check the table exist or not
	                System.out.println(query);
	                st.execute(query);
	                System.out.println("Records store");
	                
	            }
	        }catch(FileNotFoundException e) {
	        	System.out.println("File is not available in current directory");
	        }
	        catch (Exception e){
	            System.out.println(e);
	        }
	        System.out.println("Hi...");
	      
	}
	
	
	
	
	
	
	public void setDatabaseProperties() {
		 url = "jdbc:postgresql://localhost/FreshUp";
	     user = "postgres";
	     password = "postgres";
	}
	public void readPropertiesFile() throws IOException {    
		 Properties prop = readPropertiesFile("src/resource/customer.properties");
	    // Properties prop = readPropertiesFile("/home/pankaj/extdrive/InitialAssignment/General/LoaderAndMapper/src/customer.properties");
	      System.out.println("user: "+ prop.getProperty("customer_id"));
	      System.out.println("password: "+ prop.getProperty("customer_fname"));
	}
	
	
	
	
	
	
	
	
	  public static Properties readPropertiesFile(String fileName) throws IOException {
	      FileInputStream fis = null;
	      Properties prop = null;
	      try {
	         fis = new FileInputStream(fileName);
	         prop = new Properties();
	         prop.load(fis);
	      } catch(FileNotFoundException fnfe) {
	         fnfe.printStackTrace();
	      } catch(IOException ioe) {
	         ioe.printStackTrace();
	      } finally {
	         fis.close();
	      }
	      return prop;
	   }

}
